<div align='center'>
<img src="https://github.com/DaBluLite/Cyan/blob/master/cyan-addon-banner.png?raw=true"/>
</div>

# Cyan

A sleek and clean BetterDiscord theme, with custom background support

[Get it on BetterDiscord](https://betterdiscord.app/theme/Cyan)

Also available through the ThemeRepo plugin by DevilBro

Cyan is a sleek theme that aims to be clean, customizable and nice to the eyes.

[Addons for Cyan are available here](https://github.com/DaBluLite/Cyan/tree/master/Addons)

# Special thanks to:
* [@ObjectiveSlayer](https://github.com/ObjectiveSlayer)/carrot#8812
* [@maenDisease](https://github.com/maenDisease)/Disease#3749 
* [@lucysim9](https://github.com/lucysim9)/lucism#3987
* [@Lavender-Discord](https://github.com/Lavender-Discord) - [@Obscure-Git](https://github.com/Obscure-Git)/Obscure.#4719

# Screenshots
<div align='center'>
<img src="https://github.com/DaBluLite/Cyan/blob/master/screenshots/cyan-screenshot-1.png?raw=true"/>
</div>
<div align='center'>
<img src="https://github.com/DaBluLite/Cyan/blob/master/screenshots/cyan-screenshot-2.png?raw=true"/>
</div>

# Alternative theme banner
<div align='center'>
<img src="https://github.com/DaBluLite/Cyan/blob/master/cyan-addon-banner-alt.png?raw=true"/>
</div>
